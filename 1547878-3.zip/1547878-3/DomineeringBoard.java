// Domineering abstract board methods.
// Remember we require an immutable implementation.
// So we can change things only after cloning.

/*
Next choose how to represent your board. A boolean 2-dimensional array
is the simplest choice, and should be reasonably efficient for small
boards, say 8x8 or less.
*/


import java.util.*;


public class DomineeringBoard extends Board<DomineeringMove> {

    // Rename the players for this particular game:
	private static final Player H = Player.MINIMIZER;
	private static final Player V = Player.MAXIMIZER;
    
    private final boolean array[][];
    
    // We use the following class fields to represent the board:
    private final HashSet<DomineeringMove> hMoves;
	private final HashSet<DomineeringMove> vMoves;
    // NB. Finality is not enough to ensure immutability! (Why?)
    
	

	public DomineeringBoard() {
        //intial 4 x 4 board as asked for in Part 1
        // intially set all booleans in board array to false, i.e. there is no move in them/ they have not been played.
	    array = new boolean[4][4];
		for (int i = 1; i < 4; i++) {
			for (int j = 0; j < 4; j++) 
                {
				        array[i][j] = false;
                }
		}

		hMoves = new HashSet<>();
		vMoves = new HashSet<>();
	}

	public DomineeringBoard(int m, int n) {
		array = new boolean[m][n];

		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				array[i][j] = false;
			}
		}

		hMoves = new HashSet<>();
		vMoves = new HashSet<>();
	}

	private DomineeringBoard(HashSet<DomineeringMove> hMoves, HashSet<DomineeringMove> vMoves, boolean array[][]) {
		assert(disjoint(hMoves,vMoves));
		this.hMoves = hMoves;
		this.vMoves = vMoves;
		this.array = array;
	}
    
// Now the abstract class methods we need to implement to define
// domineering

// The usual convention is that H is the first player:
    
/*
public Player nextPlayer();

    Who plays next in this board?
*/

	@Override
	public Player nextPlayer() 
    {
        int totalMoves = (hMoves.size() + vMoves.size());
        int totalMovesRemainder = totalMoves % 2;
        if(totalMovesRemainder == 0)
            {
            return H;
            }
        else 
            {
            return V;
            }
		
	}

	@Override
    public HashSet<DomineeringMove> availableMoves() {
        //create empty HashSet to return if an error occures whereby neither H or v are next
        HashSet<DomineeringMove> availableMovesNil = new HashSet<DomineeringMove>();
        if(nextPlayer() == H)
        {
        HashSet<DomineeringMove> availableMoves = new HashSet<DomineeringMove>();
			
			for(int i = 0; i < array.length-1; i++){
				for(int j = 0; j < array[0].length; j++){
					if(array[i][j]== false){
                        if(array[i+1][j]== false)
                        {
                           availableMoves.add(new DomineeringMove(i, j, i + 1, j)); 
                        }
                    }
                    
				}
			}
			
			return availableMoves;
        }
     if(nextPlayer()==V)
        {
         HashSet<DomineeringMove> availableMoves = new HashSet<DomineeringMove>();
			
			for(int i = 0; i < array.length; i++){
				for(int j = 0; j < array[0].length-1; j++){
					if(array[i][j]== false)
                    {
                        if(array[i][j + 1]== false)
                        {
						availableMoves.add(new DomineeringMove(i, j, i, j+1));
					   }
                    }
				}
			}
			return availableMoves;
			
        }
        return availableMovesNil;
		
	}
    
 /*What is the value of this board? 
         1 if H has won (it's V's turn to play, but there are no available V moves)
         0 if nobody has won so far
        -1 if V has own (it's H's turn to play, but there are no available H moves) */

	@Override
	int value() {
		boolean ifAvailableMove = true;
		
		for(int i =0; i< array.length; i++){
			for(int j = 0; j < array[0].length; j++){
				if(array[i][j] == false){
                    if(ifAvailableMove=true)
                        {
					       ifAvailableMove = false;
                        }
				}
			}
		}
		
		if(ifAvailableMove == true)
            { if(nextPlayer() == H)
                {
                return -1;
                }
             else
                {
                return 1;
                }
            }
		
		if(DomineeringMove.winsH(array) == true)
        {
            return 1;
        }
        if(DomineeringMove.winsV(array)== true){
            return -1;
        }
        return 0;
	}
  
// We create a new board after playing a move:
 /*Creates a fresh copy of this board, and plays the move in the
         new copy, which is then returned.

         To create a freash copy, use clone(), or create a new array
         and "manually" copy the elements using a nested for-loop.

         This is because boards are required to be immutable. Once
         they are created, they should not be changed (because other
         parts of the program may be referring to them, such as nodes
         in the game tree). */

	@Override
	Board<DomineeringMove> play(DomineeringMove move) 
        {
	    if (nextPlayer() == H)
            {
	           return new DomineeringBoard(add(hMoves,move), vMoves, newArray(array, move));
            }
	    else
        {
	   return new DomineeringBoard(hMoves, add(vMoves,move), newArray(array, move));
	    }
	    
	}
	
//add move to copy of array
    
	private boolean[][] newArray(boolean[][] array, DomineeringMove newMove){
		boolean[][] copyOfArray = new boolean[array.length][array[0].length];
        
        int x = newMove.getX();
		int y = newMove.getY();
		int a = newMove.getA();
		int b = newMove.getB();
        
		for(int i = 0; i < array.length; i++){
			for(int j = 0; j < array[i].length; j++){
				copyOfArray[i][j] = array[i][j];
			}
		}
        
		if(copyOfArray[x][y] == false)
            
        {
            copyOfArray[x][y] = true;
        }
        
		if(copyOfArray[a][b] == false)
        {
            copyOfArray[a][b] = true;
        }
		
		
		return copyOfArray;
		
	}

    // A simple conversion to string for testing:

	
	  public String toString() {
          
          String boardPrint = "\n0   1   2   3";
		  boardPrint = boardPrint + "\n--+---+---+---+\n";
          String squareImage = "";
          		  
		  for(int i = 0; i < array[0].length; i++){
			  for(int j = 0; j < array.length; j++)
              {
                if(array[j][i] == false)
                {
                    squareImage = "-";
                }
                else
                {
                    squareImage = "X";
                }
				 boardPrint = boardPrint + squareImage + " | ";
			  }
              boardPrint = boardPrint + i;
			  boardPrint = boardPrint + "\n--+---+---+---+\n";
              
		  }
		  
		  return boardPrint;
	  }

// The following short private methods are for readability. They
// ensure immutability.
    
// We promise we won't change the set a (so we clone it):



		static private HashSet<DomineeringMove> intersection(HashSet<DomineeringMove> a, HashSet<DomineeringMove> b) {
			@SuppressWarnings("unchecked")
			HashSet<DomineeringMove> c = (HashSet<DomineeringMove>) a.clone(); 
            // a.clone();
			c.retainAll(b);
			return c;
		}

		static private boolean disjoint(HashSet<DomineeringMove> a, HashSet<DomineeringMove> b) {
			return (intersection(a, b).isEmpty());
		}
	
/*

NOT USED

static private boolean union(HashSet<DomineeringMove> a, HashSet<DomineeringMove> b) {
    boolean<DomineeringMove> c = (HashSet<DomineeringMove>) a.clone(); // a.clone();
    c.addAll(b);
    return c;
  }   */
    
	static private HashSet<DomineeringMove> add(HashSet<DomineeringMove> a, DomineeringMove b) {
			@SuppressWarnings("unchecked")
			HashSet<DomineeringMove> c = (HashSet<DomineeringMove>) a.clone(); 
			c.add(b);
			return c;
		} 
    
/*     
NOT USED
static private EnumSet<TTTMove> complement(EnumSet<TTTMove> a) {
    return(EnumSet.complementOf(a)); 
  }  */
    
    
	}
/*
// Tic-tac-toe abstract board methods.
// Remember we require an immutable implementation.
// So we can change things only after cloning.

import java.util.*;

public class TTTBoard extends Board<TTTMove>{
  // Rename the players for this particular game:
  private static final Player X = Player.MAXIMIZER;
  private static final Player O = Player.MINIMIZER;

  // We use the following class fields to represent the board:
  private final EnumSet<TTTMove> xMoves;
  private final EnumSet<TTTMove> oMoves;
  // NB. Finality is not enough to ensure immutability! (Why?)

  // A public method to construct the initial board:
  public TTTBoard() {
    xMoves = TTTMove.noMoves();
    oMoves = TTTMove.noMoves();
  }

  // All other constructors should be private (why?):
  private TTTBoard(EnumSet<TTTMove> xMoves, EnumSet<TTTMove> oMoves) 
  {
    assert(disjoint(xMoves,oMoves));
    this.xMoves  = xMoves;
    this.oMoves  = oMoves;
  }


  // Now the abstract class methods we need to implement to define
  // tic-tac-toe.


  // The usual convention is that X is the first player:
  public Player nextPlayer() {
    return ((xMoves.size() + oMoves.size()) % 2 == 0 ? X : O);
  }

  public EnumSet<TTTMove> availableMoves(){
    return ( value() == 0
               ? complement(union(xMoves,oMoves))
               : TTTMove.noMoves() );
  } 

  public int value(){
    return ( TTTMove.wins(xMoves) 
                ? 1
                : TTTMove.wins(oMoves)
                     ? -1
                     :  0 );
  } 

  // We create a new board after playing a move:
  public TTTBoard play(TTTMove move){
    assert(!xMoves.contains(move) && !oMoves.contains(move));

    if (nextPlayer() == X)
      return new TTTBoard(add(xMoves,move), oMoves);
    else
      return new TTTBoard(xMoves, add(oMoves,move));
  }

  // A simple conversion to string for testing:
  public String toString() {
    return(pm(TTTMove.A0) + " | " +  pm(TTTMove.A1) + " | " +  pm(TTTMove.A2) + "\n"
         + "---+----+---\n"
         + pm(TTTMove.B0) + " | " +  pm(TTTMove.B1) + " | " +  pm(TTTMove.B2) + "\n"
         + "---+----+---\n"
         + pm(TTTMove.C0) + " | " +  pm(TTTMove.C1) + " | " +  pm(TTTMove.C2) + "\n");
  } 

  private String pm(TTTMove m) {
    return(xMoves.contains(m) ? "X " : oMoves.contains(m) ? "O " : m.toString());
  }

  // The following short private methods are for readability. They
  // ensure immutability.

  // We promise we won't change the set a (so we clone it):
  static private EnumSet<TTTMove> intersection(EnumSet<TTTMove> a, EnumSet<TTTMove> b) {
    EnumSet<TTTMove> c = EnumSet.copyOf(a); // a.clone();
    c.retainAll(b);
    return c;
  }

  static private boolean disjoint(EnumSet<TTTMove> a, EnumSet<TTTMove> b) {
    return(intersection(a,b).isEmpty());
  }

  static private EnumSet<TTTMove> union(EnumSet<TTTMove> a, EnumSet<TTTMove> b) {
    EnumSet<TTTMove> c = EnumSet.copyOf(a); // a.clone();
    c.addAll(b);
    return c;
  }  

  static private EnumSet<TTTMove> add(EnumSet<TTTMove> a, TTTMove b) {
    EnumSet<TTTMove> c = EnumSet.copyOf(a); // .clone();
    c.add(b);
    return c;
  }  

  static private EnumSet<TTTMove> complement(EnumSet<TTTMove> a) {
    return(EnumSet.complementOf(a));
  }  
}*/