import java.util.*;

/*

First choose how to represent your moves. There isn't much choice here,
other than coordinates x,y. (Some people are using Point.)

   -----+-----+-----+-----
    0,0 | 1,0 | 2,0 | 3,0 |
   -----+-----+-----+-----
    0,1 | 1,1 | 2,1 | 3,1 |
   -----+-----+-----+-----
    0,2 | 1,2 | 2,2 | 3,2 |
   -----+-----+-----+-----
    0,3 | 1,3 | 2,3 | 3,3 |
   -----+-----+-----+-----

*/



public class DomineeringMove {
	
	private int x;
	private int y;
	private int a;
	private int b;

    // Some helper data and methods:

	public DomineeringMove(int x, int y, int a, int b){
		this.x = x;
		this.y = y;
		this.a = a;
		this.b = b;
	}
	
	public int getX()
    {
		return this.x;
	}
	public int getY()
    {
		return this.y;
	}
	public int getA()
    {
		return this.a;
	}
	public int getB()
    {
		return this.b;
	}
	
	public static boolean winsH(boolean array[][]){
		boolean endResult = true;
		for(int i = 0; i < array.length; i++){
			for(int j = 0; j < array[0].length-1; j++){
					if(array[i][j] == false)
                    {
                        if(array[i][j+1] == false)
                        {
                            endResult = false;
                        }
                    }
        
			}
		}
		return endResult;
		
	}
    
    public static boolean winsV(boolean array[][]){
		boolean endResult = true;
		for(int i = 0; i < array.length - 1; i++){
			for(int j = 0; j < array[0].length; j++){
					if(array[i][j] ==false)
                    {
                        if(array[i+1][j] == false)
                        {
                            endResult = false;
                        }
                    }
        
			}
		}
		return endResult;
    }
    
	public String toString()
    {
        /*{
        *converts coordinate values back into form x,y. 
        *this is the reverse of the method in commandlinedomineering
        }*/
        
        String iPlayMove = "(" + x + "";
        iPlayMove = iPlayMove + ",";
        iPlayMove = iPlayMove + y + "" +")";
		return iPlayMove;  
	}
    
     /*
    However, there is a potential trap. Because we are using hash tables in the provided GameTree code, you must define an equals() method for move objects, and hence also hashCode(). This should be so that two equal things should have the same hash code. Maybe I'll add a recipe. For the moment ask the demonstrators.
    */
    
	public int hashCode()
    /*{
    *number 31 taken from http://stackoverflow.com/questions/3613102/why-use-a-prime-number-in-hashcode which 
    *explains why the number should be prime
    */    
    {
		return 31*this.getX() + 3131*this.getY() + 313131*this.getA() + 31313131*this.getB();
	}
	
   
    
	public boolean equals(Object obj){
		boolean endResult = false;
		if((obj instanceof DomineeringMove) == false)
            {
            endResult = false;
		  }else
        {
			DomineeringMove move = (DomineeringMove) obj;
            int same = 0;
            
			if(move.getX() == this.getX())
            {
                same = same+1;
            }   
            if(move.getY() == this.getY())
            {
                same = same+1;
            }   
            if(move.getA() == this.getA())
            {
                same = same+1;
            }
            if(move.getB() == this.getB())
            {
                same = same+1;
            }
            if(same == 4)
            {
                endResult = true;
            }
            
            
          }
		
		return endResult; 
	} 
}

/* {
import java.util.*;


    A0 | A1 | A2
   ----+----+----
    B0 | B1 | B2
   ----+----+----
    C0 | C1 | C2


public enum TTTMove {
  A0, A1, A2, B0, B1, B2, C0, C1, C2;

  // Some helper data and methods:

  static private final TTTMove first = A0;
  static private final TTTMove last  = C2;
  static private final EnumSet<TTTMove> lineA = EnumSet.of(A0,A1,A2);
  static private final EnumSet<TTTMove> lineB = EnumSet.of(B0,B1,B2);
  static private final EnumSet<TTTMove> lineC = EnumSet.of(C0,C1,C2);
  static private final EnumSet<TTTMove> col0  = EnumSet.of(A0,B0,C0);
  static private final EnumSet<TTTMove> col1  = EnumSet.of(A1,B1,C1);
  static private final EnumSet<TTTMove> col2  = EnumSet.of(A2,B2,C2);
  static private final EnumSet<TTTMove> diagD = EnumSet.of(A0,B1,C2);
  static private final EnumSet<TTTMove> diagU = EnumSet.of(C0,B1,A2);

  public static boolean wins(EnumSet<TTTMove> moves) {
    return (  moves.containsAll(lineA) 
           || moves.containsAll(lineB) 
           || moves.containsAll(lineC) 
           || moves.containsAll(col0) 
           || moves.containsAll(col1) 
           || moves.containsAll(col2) 
           || moves.containsAll(diagD) 
           || moves.containsAll(diagU) );
  }

  static public EnumSet<TTTMove> allMoves() {
    return(EnumSet.range(first,last));
  } 

  static public EnumSet<TTTMove> noMoves() {
    return(EnumSet.noneOf(TTTMove.class));
  }  
}
}
*/



