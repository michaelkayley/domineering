import java.util.*;



public class CommandLineDomineering {
	
	private static class CommandLineDomi implements MoveChannel<DomineeringMove>{

		
		@Override
		public DomineeringMove getMove() {
            //scanner = new Scanner(System.in);
            Scanner input = new Scanner(System.in);
			System.out.println("Input your coordinates x,y");
            
            String coordinate = input.nextLine();
            String parts[] = coordinate.split(","); 
            
            String x = parts[0];
            String y = parts[1];
            
            int x1 = Integer.parseInt(x);
            int y1 = Integer.parseInt(y);
            int y2 = y1 + 1;
            
			return new DomineeringMove(x1, y1, x1, y2);
		}

	
		@Override
		public void giveMove(DomineeringMove move) {
			System.out.println("I play " + move);
		}

		
		@Override
		public void end(int Value) 
        {
			System.out.println("Game over. The result is " + Value);
		}
        
        @Override
		public void comment(String msg) {
		      System.out.println(msg);
		}


	}

	public static void main(String[] args) {
        System.out.println("\n You are playing as vertical");
        System.out.println("\n Please enter your moves as x,y with no spaces");
        System.out.println("\n Horizontal to play first");
		DomineeringBoard board = new DomineeringBoard();
        board.tree().firstPlayer(new CommandLineDomi());

	}

}
